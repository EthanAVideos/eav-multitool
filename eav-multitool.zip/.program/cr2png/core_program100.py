#All Rights Reserved To EthanA Videos, The Developer
#Date Made: 4-17-24
#Date Last Updated: 4-17-24
#Version: 1.0.0

import os
import sys
import logging
from datetime import datetime
from rawpy import imread
from PIL import Image

# Set up logging
logging.basicConfig(filename='../../output/cr2png/cr2png_conversion_log.txt', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

def convert_cr2_to_png(input_folder, output_folder):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    for filename in os.listdir(input_folder):
        if filename.endswith(".CR2"):
            try:
                # Read the CR2 file
                raw = imread(os.path.join(input_folder, filename))
                # Convert to RGB
                rgb = raw.postprocess()
                # Save as PNG
                png_filename = os.path.splitext(filename)[0] + '.png'
                Image.fromarray(rgb).save(os.path.join(output_folder, png_filename))
                logging.info(f"Converted {filename} to {png_filename} and saved in {output_folder}")
            except Exception as e:
                logging.error(f"Error converting {filename}: {e}")

if __name__ == "__main__":
    input_folder = '../../input/cr2png'
    output_folder = '../../output/cr2png'
    convert_cr2_to_png(input_folder, output_folder)

