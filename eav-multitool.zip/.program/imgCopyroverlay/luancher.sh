#!/bin/bash

#All Rights Reserved EthanA Videos, Developer
#Date Made:04-19-24
#Date Last Updated: 04-19-24
#Version: 1.0.0
#Description: Allows you to luanch a specific program right away without using the default multi-luancher. 


# Change the working directory to the directory of this script
cd "$(dirname "$0")"

python3 core_program101.py
