#All Right Reserved EthanA Videos, The Developer.
#Date Made: 04-24
#Update Date: 04-17-24
#Version: 1.0.1

import os
import glob
from PIL import Image

input_dir = '../../input/copyroverlay/'
output_dir = '../../output/copyroverlay/'
copyright_png = '../../templates/copyright.png'

os.makedirs(output_dir, exist_ok=True)

# Open the copyright PNG
copyright = Image.open(copyright_png)

for img_path in glob.glob(os.path.join(input_dir, "*")):
 # Open the image
 img = Image.open(img_path)
 
 # Resize the copyright image to match the size of the original image
 copyright = copyright.resize(img.size, Image.LANCZOS)
 
 # Ensure the copyright PNG is in RGBA mode
 copyright = copyright.convert('RGBA')
 
 # Overlay the copyright PNG on the image
 img.paste(copyright, (0, 0), copyright)
 
 # Resize the image
 img = img.resize((1920, 1080), Image.LANCZOS) # 1920, 1080
 
 # Save the processed image in the output directory
 output_path = os.path.join(output_dir, os.path.basename(img_path))
 img.save(output_path)

