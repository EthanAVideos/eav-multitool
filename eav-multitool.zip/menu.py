import tkinter as tk
import subprocess
import os
import signal
from tkinter import messagebox

# Store subprocesses for child scripts
child_processes = []

def run_script(script_name):
    """Run a Python script in a new process and add it to the list of child processes."""
    try:
        process = subprocess.Popen(['python3', script_name])
        child_processes.append(process)
    except Exception as e:
        messagebox.showerror("Error", f"Failed to run {script_name}: {e}")

def run_shell_script(script_name):
    """Run a shell script in a new process."""
    try:
        subprocess.Popen(['bash', script_name])
    except Exception as e:
        messagebox.showerror("Error", f"Failed to run {script_name}: {e}")

def open_settings():
    """Open the Settings window with buttons and version label."""
    settings_window = tk.Toplevel(root)
    settings_window.title("Settings")
    settings_window.geometry("300x200")

    # Check For Update button
    update_button = tk.Button(settings_window, text="Check For Update", command=lambda: run_shell_script('.update.sh'))
    update_button.pack(pady=10)

    # Uninstall button
    uninstall_button = tk.Button(settings_window, text="Uninstall", command=lambda: run_shell_script('.uninstall.sh'))
    uninstall_button.pack(pady=10)

    # Version label
    version_label = tk.Label(settings_window, text="Version: 2.0.0", anchor='w')
    version_label.place(x=10, y=160)  # Positioned in the bottom-left

def on_closing():
    """Handle closing of the main menu window."""
    if any(process.poll() is None for process in child_processes):
        for process in child_processes:
            if process.poll() is None:
                os.kill(process.pid, signal.SIGTERM)  # Terminate child processes
        messagebox.showerror("Error 1", "Main program or dependencies closed while other programs were running.")
    root.destroy()

# Create the main Tkinter window
root = tk.Tk()
root.title("Main Menu")
root.geometry("400x300")
root.tk.call('wm', 'iconphoto', root._w, tk.PhotoImage(file='.graphics/run.png'))

# Top-left settings button
settings_button = tk.Button(root, text="Settings", command=open_settings)
settings_button.place(x=10, y=10)

# Main buttons with descriptions
buttons = [
    ("Run FSMUP", "FS Mod Updater", ".fsmup.py"),
    ("Run CROL", "Copyright Overlay", ".crol.py"),
    ("Run IMGCOMP", "Image Compression", ".imgcomp.py"),
]

for i, (text, desc, script_name) in enumerate(buttons):
    # Button to run each script
    button = tk.Button(root, text=text, command=lambda s=script_name: run_script(s))
    button.pack(pady=(40 if i == 0 else 10, 5))

    # Description label for each button
    label = tk.Label(root, text=desc)
    label.pack()

# Handle the main window close event
root.protocol("WM_DELETE_WINDOW", on_closing)

# Run the Tkinter event loop
root.mainloop()

