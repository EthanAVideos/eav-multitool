#!/bin/bash
# Set the working directory to the location of the .desktop file
DIR="$(dirname "$(realpath "$0")")"
# Run the Python script
python3 "$DIR/menu.py"

