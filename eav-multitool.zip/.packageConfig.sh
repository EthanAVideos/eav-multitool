#!/bin/bash

# Change the working directory to the directory of this script
cd "$(dirname "$0")"

echo "The following options will remove/uninstall the stated features/package."
echo ""
PS3='Please enter your choice: '
options=("Remove FSMUP" "Remove CR2PNG" "Remove CROL" "Uninstall All" "Quit")
select opt in "${options[@]}"
do
    case $opt in
        "Remove FSMUP")
            echo "Removing FS Mod Updater"
            sleep 1
            rm -r input/fsmup/ && rm -r output/fsmup/ && rm -r .program/fsmup/ && rm -r .program/.graphics/fsmup.png && rm -r .program/.graphics/.fsmup.svg
            echo "Finishing Up..."
            ;;
        "Remove CR2PNG")
            echo "Removing Canon Raw 2 Portable Network Graphics"
            sleep 1
            rm -r input/cr2png/ && rm -r output/cr2png/ && rm -r .program/cr2png/ && rm -r .program/.graphics/cr2png.png && rm -r .program/.graphics/.cr2png.svg
            echo "Finishing Up..."
            ;;
        "Remove CROL")
            echo "Removing Copyright Overlayer"
            sleep 1
            rm -r input/copyroverlay/ && rm -r output/copyroverlay/ && rm -r .program/imgCopyroverlay/ && rm -r .program/.graphics/crol.png && rm -r .program/.graphics/.crol.svg
            echo "Finishing Up..."
            ;;
            "Uninstall All")
            echo "Uninstalling EAV Multitool"
            sleep .5
            echo -e "\033[1m WARNING: You may see some errors as it deletes running programs, this will not uninstall python dependencies. \033[0m"
            sleep .5
            sudo rm -rf .[^.]* ./*
            ;;
        "Quit")
            break
            ;;
        *) echo "invalid option $REPLY";;
    esac
done

