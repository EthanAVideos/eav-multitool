#!/bin/bash
# All Rights Reserved EthanA Videos, Developer
# Date Made: 04-17-24
# Date Last Updated: 11-15-24
# Version: 1.1.3
# System Version: Linux (Deb)

# Change the working directory to the directory of this script
cd "$(dirname "$0")"

echo "Loading..."

# Function to check if a Python library is installed
check_library() {
    if python3 -c "import $1" &> /dev/null; then
        echo "$1 is installed"
        if pip3 show $1 | grep -q 'Version'; then
            installed_version=$(pip3 show $1 | grep 'Version' | awk '{print $2}')
            latest_version=$(pip3 search $1 | grep '^'$1 | awk '{print $2}')
            if [[ "$installed_version" == "$latest_version" ]]; then
                echo "$1 is up to date"
            else
                echo "Updating $1"
                pip3 install --upgrade $1
                echo "$1 has been updated"
            fi
        fi
    else
        echo "Installing $1"
        pip3 install $1
        echo "$1 has been installed"
    fi
}

# Function to update files from GitHub
update_from_github() {
    local_version=$(cat version.txt)
    github_version=$(curl -sSL https://raw.githubusercontent.com/EthanAVideos/eav-multitool/main/version.txt)
    
    echo "Local version: $local_version"
    echo "GitHub version: $github_version"
    
    # Split version numbers into components
    IFS='.' read -r -a local_version_arr <<< "$local_version"
    IFS='.' read -r -a github_version_arr <<< "$github_version"
    
    echo "Local version array: ${local_version_arr[@]}"
    echo "GitHub version array: ${github_version_arr[@]}"
    
    # Compare version numbers
    should_update=false
    for (( i=0; i<${#local_version_arr[@]}; i++ )); do
        echo "Comparing component ${local_version_arr[i]} with ${github_version_arr[i]}"
        if [[ "${github_version_arr[i]}" -gt "${local_version_arr[i]}" ]]; then
            should_update=true
            break
        elif [[ "${github_version_arr[i]}" -lt "${local_version_arr[i]}" ]]; then
            break
        fi
    done
    
    if [[ "$should_update" == true ]]; then
        echo "New version available. Updating..."
        # Download and unzip from GitHub
        wget https://github.com/EthanAVideos/eav-multitool/raw/main/eav-multitool.zip  #https://github.com/EthanAVideos/eav-multitool/archive/refs/heads/main.zip
        echo "Download complete"
        unzip -o eav-multitool.zip -d ./ 
        echo "Extraction complete"
        # Move files and folders to main directory
        echo "Moving files and folders..."
        #mv eav-multitool/* ./ && mv version.txt .program/
        echo "Files and folders moved"
        rm -r eav-multitool.zip
        echo "Cleanup complete"
        # Update version.txt in the .program directory
        echo "$github_version" > .program/version.txt
        echo "Updated version.txt in .program directory"
    else
        echo "Installed version is up to date"
    fi
}

# Check and install/update Python libraries
check_library rawpy
check_library Pillow --break-system-packages
check_library tkinter --break-system-packages
check_library ttk

# Call the update_from_github function
update_from_github

