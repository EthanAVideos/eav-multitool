#!/bin/bash
#All Rights Reserved EthanA Videos, Developer
#Date Made: 04-17024
#Date Last Updated: 04-17-24
#Version: 1.0.0
#System Version: Linux (Deb)


# Change the working directory to the directory of this script
cd "$(dirname "$0")"

echo "Loading..."
sleep .5
echo "Running..."
sleep .2

#!/bin/bash

# Define the GitHub URL for the version.txt file and the zipped file
GITHUB_VERSION_URL="https://raw.githubusercontent.com/EthanAVideos/eav-multitool/main/version.txt"
GITHUB_ZIP_URL="https://github.com/yourusername/yourrepository/archive/refs/heads/main.zip"

# Define the local paths
LOCAL_VERSION_FILE=".program/version.txt"
LOCAL_PROGRAM_DIR=".program"

# Function to check if a Python library is installed
check_python_library() {
    pip show "$1" > /dev/null 2>&1
    return $?
}

# Function to update a Python library
update_python_library() {
    pip install --upgrade "$1"
}

# Check and update Python libraries
libraries=("Pillow" "rawpy") # Add other libraries as needed
for lib in "${libraries[@]}"; do
    if check_python_library "$lib"; then
        echo "Library $lib is installed."
        update_python_library "$lib"
    else
        echo "Library $lib is not installed. Installing..."
        pip install "$lib"
    fi
done

# Check the local version
if [ -f "$LOCAL_VERSION_FILE" ]; then
    LOCAL_VERSION=$(cat "$LOCAL_VERSION_FILE")
else
    echo "Local version file not found."
    exit 1
fi

# Fetch the GitHub version
GITHUB_VERSION=$(curl -s "$GITHUB_VERSION_URL")

# Compare versions
if [ "$LOCAL_VERSION" -ge "$GITHUB_VERSION" ]; then
    echo "Installed version is up to date."
else
    echo "A newer version is available on GitHub."
    # Download and unzip the GitHub version
    curl -L "$GITHUB_ZIP_URL" -o update.zip
    unzip -o update.zip -d "$LOCAL_PROGRAM_DIR"
    rm update.zip
    echo "Update completed."
fi

