import os
import glob
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import ttk
from PIL import Image

# Default values
input_dir = 'input/copyroverlay/'
output_dir = 'output/copyroverlay/'
copyright_png = 'templates/copyright.png'
resize_width = 1920
resize_height = 1080

# Main GUI window
root = tk.Tk()
root.title("CROL - Copyright Overlay Tool")
root.geometry("600x650")
root.tk.call('wm', 'iconphoto', root._w, tk.PhotoImage(file='.graphics/crol.png'))

# Update the process images function
def process_images():
    try:
        # Get resize dimensions from entries
        global resize_width, resize_height
        resize_width = int(resize_width_entry.get())
        resize_height = int(resize_height_entry.get())

        # Collect image files from input directory
        files = glob.glob(os.path.join(input_dir, "*"))
        image_files = [f for f in files if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif'))]
        num_files = len(image_files)

        if num_files == 0:
            messagebox.showwarning("No Files", "No images found in the input directory.")
            return

        # Set up progress bar
        progress_bar["maximum"] = num_files
        for i, img_path in enumerate(image_files):
            img = Image.open(img_path)
            overlay = Image.open(copyright_png)

            # Resize overlay to match the image size
            overlay = overlay.resize(img.size, Image.LANCZOS).convert('RGBA')
            img.paste(overlay, (0, 0), overlay)

            # Resize the final image with updated dimensions
            img = img.resize((resize_width, resize_height), Image.LANCZOS)

            # Save to output directory
            output_path = os.path.join(output_dir, os.path.basename(img_path))
            img.save(output_path)
            
            # Update progress bar
            progress_bar["value"] = i + 1
            root.update_idletasks()

        messagebox.showinfo("Process Complete", "Image overlay process completed successfully.")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")
    finally:
        run_button["state"] = "normal"

# Configure settings
def configure_settings():
    global input_dir, output_dir, copyright_png
    input_dir = input_dir_entry.get()
    output_dir = output_dir_entry.get()
    copyright_png = copyright_image_entry.get()
    messagebox.showinfo("Settings Saved", "Configuration saved successfully.")

# File and directory selection functions
def set_input_dir():
    global input_dir
    input_dir = filedialog.askdirectory()
    input_dir_entry.delete(0, tk.END)
    input_dir_entry.insert(0, input_dir)

def set_output_dir():
    global output_dir
    output_dir = filedialog.askdirectory()
    output_dir_entry.delete(0, tk.END)
    output_dir_entry.insert(0, output_dir)

def set_copyright_image():
    global copyright_png
    copyright_png = filedialog.askopenfilename(filetypes=[("PNG files", "*.png")])
    copyright_image_entry.delete(0, tk.END)
    copyright_image_entry.insert(0, copyright_png)

# GUI layout
tk.Label(root, text="CROL Version: 2.0.1").place(x=10, y=10)

# Run Process Button
run_button = tk.Button(root, text="Run Process", command=process_images)
run_button.pack(pady=55)

# Progress Bar
progress_bar = ttk.Progressbar(root, orient="horizontal", length=300, mode="determinate")
progress_bar.pack(pady=10)

# Configuration Section
tk.Label(root, text="Configure").pack(pady=10)

# Input Directory
tk.Label(root, text="Input Directory:").pack()
input_dir_entry = tk.Entry(root, width=50)
input_dir_entry.insert(0, input_dir)
input_dir_entry.pack()
tk.Button(root, text="Set Input Directory", command=set_input_dir).pack(pady=5)

# Output Directory
tk.Label(root, text="Output Directory:").pack()
output_dir_entry = tk.Entry(root, width=50)
output_dir_entry.insert(0, output_dir)
output_dir_entry.pack()
tk.Button(root, text="Set Output Directory", command=set_output_dir).pack(pady=5)

# Copyright Image
tk.Label(root, text="Copyright Image:").pack()
copyright_image_entry = tk.Entry(root, width=50)
copyright_image_entry.insert(0, copyright_png)
copyright_image_entry.pack()
tk.Button(root, text="Set Copyright Image", command=set_copyright_image).pack(pady=5)

# Resize Dimensions
tk.Label(root, text="Resize Width:").pack()
resize_width_entry = tk.Entry(root, width=10)
resize_width_entry.insert(0, resize_width)
resize_width_entry.pack()

tk.Label(root, text="Resize Height:").pack()
resize_height_entry = tk.Entry(root, width=10)
resize_height_entry.insert(0, resize_height)
resize_height_entry.pack()

# Save Button
tk.Button(root, text="Save", command=configure_settings).pack(pady=10)

root.mainloop()

