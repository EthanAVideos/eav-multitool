#!/bin/bash
# All Rights Reserved EthanA Videos, Developer
# Date Made: 04-17-24
# Date Last Updated: 04-20-24
# Version: 1.0.2
# System Version: Linux (Deb)

# Change the working directory to the directory of this script
cd "$(dirname "$0")"

echo "Uninstalling..."
cd ../
rm -rf eav-multitool/

