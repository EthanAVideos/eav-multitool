#!/bin/bash

#All Rights Reserved EthanA Videos, Developer
#Date Made: 04-17-24
#Date Last Updated: 04-17-24
#Version: 1.0.0

# Change the working directory to the directory of this script
cd "$(dirname "$0")"

PS3='Please enter your choice: '
options=("CopyRightOverlay" "FSMUP" "CR2PNG" "Reset" "Information" "Check For Updates" "Configure" "Quit")
select opt in "${options[@]}"
do
    case $opt in
        "CopyRightOverlay")
            echo "Opening Path..."
            cd .program/imgCopyroverlay
            echo "Loading CROL v1.0.1..."
            sleep .5
            echo "Running..."
            python3 core_program101.py
            echo "Finishing Up..."
            ;;
        "FSMUP")
            echo "Opening Path..."
            cd .program/fsmup
            echo "Loading FSMUP v2.0.5..."
            sleep .5
            echo "Running..."
            python3 core_program205.py
            echo "Finishing Up..."
            ;;
        "CR2PNG")
            echo "Opening Path..."
            cd .program/cr2png
            echo "Loading CR2PNG v1.0.0..."
            sleep .5
            echo "Running..."
            python3 core_program100.py
            #.program/cr2png/
            echo "Finishing Up..."
            ;;
            "Reset")
                echo "Only Run If You Have Ran A Option & Going To Run Another."
                sleep 3
                cd ../../
                echo "Done!"
            ;;
            "Information")
            echo "Reading information..."
            sleep .5
            cat documents/.information.txt
            ;;
            "Check For Updates")
            echo "Running update script..."
            ./update.sh
            ;;
            "Configure")
            echo "Loading config script..."
            sleep .5
            echo -e "\033[1mWARNING: You May Brake The Install or Packages May Be Missing\033[0m"
            ./.packageConfig.sh
             echo "Finishing Up..."
            ;;
        "Quit")
            break
            ;;
        *) echo "invalid option $REPLY";;
    esac
done

