import os
import glob
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import ttk
from PIL import Image
from datetime import datetime

# Default values
input_dir = 'input/imgcomp/'
output_dir = 'output/imgcomp/'
log_file = 'output/imgcomp/compression_log.txt'
quality_level = 1
image_format = 'PNG'  # Default output format

# Supported image formats
SUPPORTED_FORMATS = ('.png', '.jpg', '.jpeg', '.webp', '.bmp', '.tiff')

# Main GUI window
root = tk.Tk()
root.title("IMGCOMP - Image Compression Tool")
root.geometry("600x650")
root.tk.call('wm', 'iconphoto', root._w, tk.PhotoImage(file='.graphics/imgcomp.png'))

# Function to compress images
def compress_images():
    try:
        # Get quality level from entry
        global quality_level
        quality_level = int(quality_entry.get())

        # Collect image files from input directory
        files = glob.glob(os.path.join(input_dir, "*"))
        image_files = [f for f in files if f.lower().endswith(SUPPORTED_FORMATS)]
        num_files = len(image_files)

        if num_files == 0:
            messagebox.showwarning("No Files", "No supported image files found in the input directory.")
            return

        # Ensure output directory exists
        os.makedirs(output_dir, exist_ok=True)

        # Set up progress bar
        progress_bar["maximum"] = num_files
        for i, img_path in enumerate(image_files):
            img = Image.open(img_path)

            # Get the old file size
            old_size = os.path.getsize(img_path)

            # Save the compressed image in the selected format
            output_filename = os.path.splitext(os.path.basename(img_path))[0] + f".{image_format.lower()}"
            output_path = os.path.join(output_dir, output_filename)
            img.save(output_path, image_format, quality=quality_level, optimize=True)

            # Get the new file size
            new_size = os.path.getsize(output_path)

            # Log the compression details
            with open(log_file, 'a') as f:
                size_saved = ((old_size - new_size) / old_size) * 100
                f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - {os.path.basename(img_path)} - "
                        f"Old size: {old_size} bytes - New size: {new_size} bytes - Size saved: {size_saved:.2f}%\n")

            # Update progress bar
            progress_bar["value"] = i + 1
            root.update_idletasks()

        messagebox.showinfo("Process Complete", "Image compression process completed successfully.")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")
    finally:
        run_button["state"] = "normal"

# Configure settings
def configure_settings():
    global input_dir, output_dir, log_file, image_format
    input_dir = input_dir_entry.get()
    output_dir = output_dir_entry.get()
    log_file = log_file_entry.get()
    image_format = format_var.get()
    messagebox.showinfo("Settings Saved", "Configuration saved successfully.")

# File and directory selection functions
def set_input_dir():
    global input_dir
    input_dir = filedialog.askdirectory()
    input_dir_entry.delete(0, tk.END)
    input_dir_entry.insert(0, input_dir)

def set_output_dir():
    global output_dir
    output_dir = filedialog.askdirectory()
    output_dir_entry.delete(0, tk.END)
    output_dir_entry.insert(0, output_dir)

def set_log_file():
    global log_file
    log_file = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
    log_file_entry.delete(0, tk.END)
    log_file_entry.insert(0, log_file)

# GUI layout
tk.Label(root, text="IMGCOMP Version: 2.0.0").place(x=10, y=10)

# Run Process Button
run_button = tk.Button(root, text="Run Process", command=compress_images)
run_button.pack(pady=10)

# Progress Bar
progress_bar = ttk.Progressbar(root, orient="horizontal", length=300, mode="determinate")
progress_bar.pack(pady=10)

# Configuration Section
tk.Label(root, text="Configure").pack(pady=10)

# Input Directory
tk.Label(root, text="Input Directory:").pack()
input_dir_entry = tk.Entry(root, width=50)
input_dir_entry.insert(0, input_dir)
input_dir_entry.pack()
tk.Button(root, text="Set Input Directory", command=set_input_dir).pack(pady=5)

# Output Directory
tk.Label(root, text="Output Directory:").pack()
output_dir_entry = tk.Entry(root, width=50)
output_dir_entry.insert(0, output_dir)
output_dir_entry.pack()
tk.Button(root, text="Set Output Directory", command=set_output_dir).pack(pady=5)

# Log File
tk.Label(root, text="Log File:").pack()
log_file_entry = tk.Entry(root, width=50)
log_file_entry.insert(0, log_file)
log_file_entry.pack()
tk.Button(root, text="Set Log File", command=set_log_file).pack(pady=5)

# Image Format
tk.Label(root, text="Output Format:").pack()
format_var = tk.StringVar(value='PNG')  # Default to PNG
format_menu = tk.OptionMenu(root, format_var, 'PNG', 'JPEG', 'WEBP')
format_menu.pack(pady=5)

# Quality Level
tk.Label(root, text="Quality Level:").pack()
quality_entry = tk.Entry(root, width=10)
quality_entry.insert(0, quality_level)
quality_entry.pack()

# Save Button
tk.Button(root, text="Save", command=configure_settings).pack(pady=10)

root.mainloop()

