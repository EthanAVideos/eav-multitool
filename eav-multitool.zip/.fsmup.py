# All Right EthanA Videos, Developer Of This Software.
# Date Made: 9-10-23
# Date Last Updated: 11-15-24
# Version: 2.4.0

# You are not to open / change this file without written consent from EthanA Videos.

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import os
import zipfile
import xml.etree.ElementTree as ET
import shutil
import threading
import logging
import sys

# Default paths
config = {
    "input_folder": "input/fsmup",
    "output_folder": "output/fsmup",
    "log_file": "output/fsmup/fsmup_work_log.txt",
}

# Logging setup
def log_message(message):
    """Log messages to the log file."""
    logging.basicConfig(
        filename=config["log_file"],
        level=logging.INFO,
        format="%(asctime)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    logging.info(message)


def log_exception(exctype, value, tb):
    """Log uncaught exceptions."""
    formatted_exception = f"Error: {exctype.__name__}, > {value}, > line: {tb.tb_lineno}"
    log_message(formatted_exception)
    sys.__excepthook__(exctype, value, tb)


sys.excepthook = log_exception


def save_configuration():
    """Save the current configuration."""
    log_message("Configuration saved:")
    for key, value in config.items():
        log_message(f"  {key} = {value}")
    # Show popup confirmation
    messagebox.showinfo("Configuration Saved", "Your configuration has been successfully saved!")


def browse_input_folder():
    """Select input folder."""
    folder = filedialog.askdirectory(title="Select Input Folder")
    if folder:
        config["input_folder"] = folder
        input_entry.delete(0, tk.END)
        input_entry.insert(0, folder)


def browse_output_folder():
    """Select output folder."""
    folder = filedialog.askdirectory(title="Select Output Folder")
    if folder:
        config["output_folder"] = folder
        output_entry.delete(0, tk.END)
        output_entry.insert(0, folder)


def browse_log_file():
    """Select log file."""
    file_path = filedialog.asksaveasfilename(
        title="Select Log File", defaultextension=".txt", filetypes=[("Text Files", "*.txt")]
    )
    if file_path:
        config["log_file"] = file_path
        log_entry.delete(0, tk.END)
        log_entry.insert(0, file_path)


def update_mods():
    """Update mods in a separate thread."""
    update_button.config(state=tk.DISABLED)
    desc_version = desc_entry.get()
    log_message(f"Starting update with descVersion: {desc_version}")

    # Reset Summary Counters
    summary_vars["updated"].set(0)
    summary_vars["errors"].set(0)
    summary_vars["failed"].set(0)

    try:
        os.makedirs(config["output_folder"], exist_ok=True)
        zip_files = [f for f in os.listdir(config["input_folder"]) if f.endswith(".zip")]
    except Exception as e:
        log_message(f"Error accessing folders: {str(e)}")
        result_label.config(text="Error accessing folders.")
        update_button.config(state=tk.NORMAL)
        return

    total_files = len(zip_files)
    progress_var.set(0)
    result_label.config(text="Updating Mods...")

    def update_progress(i):
        progress_percentage = (i / total_files) * 100
        progress_var.set(progress_percentage)
        progress_label.config(text=f"{progress_percentage:.2f}%")
        root.update_idletasks()

    def process_zip_file(zip_file, i):
        try:
            mod_zip_path = os.path.join(config["input_folder"], zip_file)
            mod_folder = os.path.splitext(zip_file)[0]
            mod_folder_path = os.path.join(config["input_folder"], mod_folder)
            updated_mod_zip_path = os.path.join(config["output_folder"], zip_file)

            # Extract and process XML
            with zipfile.ZipFile(mod_zip_path, 'r') as zip_ref:
                zip_ref.extractall(mod_folder_path)
            xml_file_path = os.path.join(mod_folder_path, "modDesc.xml")
            if os.path.isfile(xml_file_path):
                tree = ET.parse(xml_file_path)
                mod_root = tree.getroot()
                old_version = mod_root.get("descVersion")
                mod_root.set("descVersion", desc_version)
                tree.write(xml_file_path, encoding="utf-8", xml_declaration=True)
                log_message(
                    f"Updated {zip_file}: descVersion {old_version} -> {desc_version}"
                )
                summary_vars["updated"].set(summary_vars["updated"].get() + 1)

            # Recompress the updated folder
            with zipfile.ZipFile(updated_mod_zip_path, "w", zipfile.ZIP_DEFLATED) as zip_ref:
                for foldername, subfolders, filenames in os.walk(mod_folder_path):
                    for filename in filenames:
                        file_path = os.path.join(foldername, filename)
                        arcname = os.path.relpath(file_path, mod_folder_path)
                        zip_ref.write(file_path, arcname)

            # Cleanup
            shutil.rmtree(mod_folder_path)
        except Exception as e:
            log_message(f"Error processing {zip_file}: {str(e)}")
            summary_vars["errors"].set(summary_vars["errors"].get() + 1)
            return
        finally:
            update_progress(i)

    for i, zip_file in enumerate(zip_files, start=1):
        try:
            process_zip_file(zip_file, i)
        except Exception as e:
            summary_vars["failed"].set(summary_vars["failed"].get() + 1)
            log_message(f"Critical error processing {zip_file}: {str(e)}")
            continue

    progress_var.set(100)
    result_label.config(text="Mods Updated!")
    update_button.config(state=tk.NORMAL)


# Main GUI
root = tk.Tk()
root.title("FSMUP - FS Mod Updater (v2.4.0)")
root.geometry("600x650")
root.tk.call('wm', 'iconphoto', root._w, tk.PhotoImage(file='.graphics/fsmup.png'))

# Configuration Section
config_frame = tk.Frame(root, bd=2, relief="groove", padx=10, pady=10)
config_frame.pack(pady=10, fill="x")

tk.Label(config_frame, text="Configuration", font=("Arial", 14)).pack()

tk.Label(config_frame, text="Input Folder:").pack(anchor="w")
input_frame = tk.Frame(config_frame)
input_frame.pack(fill="x", pady=5)
input_entry = tk.Entry(input_frame)
input_entry.pack(side="left", fill="x", expand=True)
input_entry.insert(0, config["input_folder"])
tk.Button(input_frame, text="Browse", command=browse_input_folder).pack(side="right")

tk.Label(config_frame, text="Output Folder:").pack(anchor="w")
output_frame = tk.Frame(config_frame)
output_frame.pack(fill="x", pady=5)
output_entry = tk.Entry(output_frame)
output_entry.pack(side="left", fill="x", expand=True)
output_entry.insert(0, config["output_folder"])
tk.Button(output_frame, text="Browse", command=browse_output_folder).pack(side="right")

tk.Label(config_frame, text="Log File:").pack(anchor="w")
log_frame = tk.Frame(config_frame)
log_frame.pack(fill="x", pady=5)
log_entry = tk.Entry(log_frame)
log_entry.pack(side="left", fill="x", expand=True)
log_entry.insert(0, config["log_file"])
tk.Button(log_frame, text="Browse", command=browse_log_file).pack(side="right")

tk.Button(config_frame, text="Save Configuration", command=save_configuration).pack(pady=10)

# DescVersion
tk.Label(root, text="Enter DescVersion:").pack()
desc_entry = tk.Entry(root)
desc_entry.pack(pady=5)

# Update Button
update_button = tk.Button(root, text="Update Mods", command=update_mods)
update_button.pack(pady=10)

# Progress Bar
progress_var = tk.DoubleVar()
progress_bar = ttk.Progressbar(root, variable=progress_var, length=300)
progress_bar.pack(pady=10)
progress_label = tk.Label(root, text="0%")
progress_label.pack()

# Summary Section
summary_vars = {"updated": tk.IntVar(), "errors": tk.IntVar(), "failed": tk.IntVar()}
summary_frame = tk.Frame(root)
summary_frame.pack(pady=5)

tk.Label(summary_frame, text="Updated").grid(row=0, column=0, padx=10)
tk.Label(summary_frame, text="Errors").grid(row=0, column=1, padx=10)
tk.Label(summary_frame, text="Failed").grid(row=0, column=2, padx=10)

tk.Label(summary_frame, textvariable=summary_vars["updated"]).grid(row=1, column=0, padx=10)
tk.Label(summary_frame, textvariable=summary_vars["errors"]).grid(row=1, column=1, padx=10)
tk.Label(summary_frame, textvariable=summary_vars["failed"]).grid(row=1, column=2, padx=10)

# Status Label
result_label = tk.Label(root, text="")
result_label.pack(pady=10)

root.mainloop()

